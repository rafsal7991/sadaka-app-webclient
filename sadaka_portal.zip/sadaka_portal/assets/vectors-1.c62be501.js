const s="/assets/vectors-1.2e444bfc.svg";export{s as V};
