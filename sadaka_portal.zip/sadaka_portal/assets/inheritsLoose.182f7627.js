import{b7 as e}from"./index.ef1be1b9.js";function p(o,t){o.prototype=Object.create(t.prototype),o.prototype.constructor=o,e(o,t)}export{p as _};
