import{a as s,j as e}from"./index.ef1be1b9.js";const n=({src:r,className:i="h-8 w-8",alt:l="image-title",imageClass:a="rounded-full",dot:t,dotClass:o=" bg-[#13317d]"})=>s("div",{className:` inline-flex shrink-0 relative ${i}  `,children:[e("img",{src:r,alt:l,className:`w-full h-full block object-cover object-center relative ring-2 ring-white ${a}  `}),t&&e("div",{className:` 
        absolute right-0 top-0 h-2.5 w-2.5 rounded-full border border-white
         dark:border-indigo-200  ${o}`})]});export{n as A};
