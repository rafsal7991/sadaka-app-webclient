import{j as r}from"./index.ef1be1b9.js";const a=()=>r("div",{children:"crm page"});export{a as default};
